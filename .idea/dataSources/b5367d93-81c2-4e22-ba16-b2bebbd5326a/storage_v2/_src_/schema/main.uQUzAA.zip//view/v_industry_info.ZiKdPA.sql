CREATE VIEW v_industry_info as
  select a.data_date, b.industry, round(avg(a.forward_pe), 2) industry_forward_pe
  from v_fundamentals a, v_companies b
  where a.ticker=b.ticker
        and a.data_date=b.data_date
  group by a.data_date, b.industry;

