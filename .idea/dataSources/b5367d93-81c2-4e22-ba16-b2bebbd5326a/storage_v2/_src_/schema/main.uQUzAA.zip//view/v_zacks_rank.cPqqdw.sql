CREATE VIEW v_zacks_rank as
  select
    ticker,
    data_date,
    overall,
    val,
    growth,
    momentum,
    vgm,

    cast(open as decimal) open,
    cast(low as decimal) low,
    cast(high as decimal) high,
    cast(low as decimal) low52,
    cast(high52 as decimal) high52,
    cast(avgv as decimal) avgv,
    dividend,
    cast(beta as decimal) beta,
    cast(replace(earning_surprise, '%', '') as decimal) earning_surprise,
    cast(most_accurate_est as decimal) most_accurate_est,
    cast(current_qtr_est as decimal) current_qtr_est,
    cast(current_yr_est as decimal) current_yr_est,
    replace(report_type, '*', '') report_type,
    case when exp_earning_date = '' then null
    else printf("20%2d-%02d-%02d", substr(substr(exp_earning_date, instr(exp_earning_date, '/')+1),  instr(substr(exp_earning_date, instr(exp_earning_date, '/')+1), '/') +1) ,
                substr(exp_earning_date, 1, instr(exp_earning_date, '/') - 1),
                substr(substr(exp_earning_date, instr(exp_earning_date, '/')+1),  1, instr(substr(exp_earning_date, instr(exp_earning_date, '/')+1), '/') - 1)
    )
    end exp_earning_date,
    cast(prior_yr_eps as decimal) prior_yr_eps,
    cast(replace(exp_growth, '%', '') as decimal) exp_growth,
    cast(forward_pe as decimal) forward_pe,
    cast(peg_ratio as decimal) peg_ratio
  from zacks_rank;

