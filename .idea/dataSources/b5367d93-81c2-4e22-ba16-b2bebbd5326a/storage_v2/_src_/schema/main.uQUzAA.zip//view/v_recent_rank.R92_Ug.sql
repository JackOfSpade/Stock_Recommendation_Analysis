CREATE VIEW v_recent_rank as
  select *
  from zacks_rank
  where data_date = (select max(data_date) from zacks_rank);

