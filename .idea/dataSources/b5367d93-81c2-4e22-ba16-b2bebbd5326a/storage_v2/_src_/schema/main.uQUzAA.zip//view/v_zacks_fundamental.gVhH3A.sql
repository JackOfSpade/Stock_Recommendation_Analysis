CREATE VIEW v_zacks_fundamental as
  select a.data_date, a.ticker, a.price, a.change_pct, a.optionable, b.beta, b.overall, b.earning_surprise, b.most_accurate_est,
    b.current_qtr_est, b.report_type, b.exp_earning_date, b.exp_growth, b.peg_ratio, a.target_price, a.volatility, a.forward_pe as fwd_pe, d.industry_forward_pe as ind_fwd_pe
  from fundamentals a left join v_zacks_rank b
      on (a.data_date=b.data_date and a.ticker=b.ticker)
    left join v_companies c
      on (a.data_date=c.data_date and a.ticker=c.ticker)
    left join v_industry_info d
      on (c.data_date = d.data_date and c.industry = d.industry);

