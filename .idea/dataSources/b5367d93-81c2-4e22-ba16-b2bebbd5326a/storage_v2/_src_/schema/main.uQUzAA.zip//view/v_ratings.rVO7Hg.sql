CREATE VIEW v_ratings as select a.*, ifnull(b.price, '') price, ifnull(b.change, '') change, ifnull(b.company, '') company, ifnull(b.industry, '') industry, ifnull(b.country, '') country
                         from recommendations a LEFT JOIN v_companies b ON (a.ticker=b.ticker  and a.data_date = b.data_date);

