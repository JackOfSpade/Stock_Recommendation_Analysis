CREATE VIEW v_ipo_dates as
  select ticker, min(data_date) as ipo_date
  from (
       select data_date, ticker
       from ipo_dates
       union all
       select min(data_date) as data_date, ticker
       from fundamentals
       group by ticker)
  group by ticker;

