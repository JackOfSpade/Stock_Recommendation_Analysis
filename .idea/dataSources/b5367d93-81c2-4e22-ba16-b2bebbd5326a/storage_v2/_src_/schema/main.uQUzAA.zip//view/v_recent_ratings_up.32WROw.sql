CREATE VIEW v_recent_ratings_up as
  select distinct a.data_date as check_date, b.* from v_ratings a, v_ratings b
  where a.ticker=b.ticker
        and ((a.recommend like '%Buy%' and a.updown != 'Downgrade')
             or a.updown = 'Upgrade'
        )      order by 2, 3 desc;

