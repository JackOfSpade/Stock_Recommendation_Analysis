CREATE VIEW v_recent_ratings_down as
  select distinct a.data_date as check_date, b.* from v_ratings a, v_ratings b
  where a.ticker=b.ticker and a.updown = 'Downgrade' order by 2, 3 desc;

