CREATE VIEW v_fundamentals as
select
    data_date                ,
    ticker                   ,
	exchange                 ,
    nullif(sindex, '-')  sindex         ,
    case substr(market_cap_m, length(market_cap_m)) when '-' then null
                                                when 'T' then cast(substr(replace(market_cap_m, ',', ''), 1, length(replace(market_cap_m, ',', '')) - 1) as decimal)*1000000
                                                when 'B' then cast(substr(replace(market_cap_m, ',', ''), 1, length(replace(market_cap_m, ',', '')) - 1) as decimal)*1000
                                                when 'M' then cast(substr(replace(market_cap_m, ',', ''), 1, length(replace(market_cap_m, ',', '')) - 1) as decimal)
												when 'K' then round(cast(substr(replace(market_cap_m, ',', ''), 1, length(replace(market_cap_m, ',', '')) - 1) as decimal)/1000.0, 2)
												else round(cast(replace(market_cap_m, ',', '') as decimal)/1000000.0, 2)
    end as market_cap_m,
    case substr(income_m, length(income_m)) when '-' then null
                                                when 'T' then cast(substr(replace(income_m, ',', ''), 1, length(replace(income_m, ',', '')) - 1) as decimal)*1000000
                                                when 'B' then cast(substr(replace(income_m, ',', ''), 1, length(replace(income_m, ',', '')) - 1) as decimal)*1000
                                                when 'M' then cast(substr(replace(income_m, ',', ''), 1, length(replace(income_m, ',', '')) - 1) as decimal)
												when 'K' then round(cast(substr(replace(income_m, ',', ''), 1, length(replace(income_m, ',', '')) - 1) as decimal)/1000.0, 2)
												else round(cast(replace(income_m, ',', '') as decimal)/1000000.0, 2)
    end as income_m,
    case substr(sales_m, length(sales_m)) when '-' then null
                                                when 'T' then cast(substr(replace(sales_m, ',', ''), 1, length(replace(sales_m, ',', '')) - 1) as decimal)*1000000
                                                when 'B' then cast(substr(replace(sales_m, ',', ''), 1, length(replace(sales_m, ',', '')) - 1) as decimal)*1000
                                                when 'M' then cast(substr(replace(sales_m, ',', ''), 1, length(replace(sales_m, ',', '')) - 1) as decimal)
												when 'K' then round(cast(substr(replace(sales_m, ',', ''), 1, length(replace(sales_m, ',', '')) - 1) as decimal)/1000.0, 2)
												else round(cast(replace(sales_m, ',', '') as decimal)/1000000.0, 2)
    end as sales_m,
    cast(replace(nullif(bs             , '-'), ',', '') as decimal)   bs                 ,
    cast(replace(nullif(cs             , '-'), ',', '') as decimal)   cs                 ,
    cast(replace(nullif(dividend       , '-'), ',', '') as decimal)   dividend           ,
    cast(replace(nullif(dividend_pct   , '-'), ',', '') as decimal)   dividend_pct       ,
    cast(replace(nullif(employees      , '-'), ',', '') as decimal)   employees          ,
    nullif(optionable     , '-')                                      optionable         ,
    nullif(shortable      , '-')                                      shortable          ,
    cast(replace(nullif(recom          , '-'), ',', '') as decimal)   recom              ,
    cast(replace(nullif(pe             , '-'), ',', '') as decimal)   pe                 ,
    cast(replace(nullif(forward_pe     , '-'), ',', '') as decimal)   forward_pe         ,
    cast(replace(nullif(peg            , '-'), ',', '') as decimal)   peg                ,
    cast(replace(nullif(ps             , '-'), ',', '') as decimal)   ps                 ,
    cast(replace(nullif(pb             , '-'), ',', '') as decimal)   pb                 ,
    cast(replace(nullif(pc             , '-'), ',', '') as decimal)   pc                 ,
    cast(replace(nullif(pfcf           , '-'), ',', '') as decimal)   pfcf               ,
    cast(replace(nullif(quick_ratio    , '-'), ',', '') as decimal)   quick_ratio        ,
    cast(replace(nullif(current_ratio  , '-'), ',', '') as decimal)   current_ratio      ,
    cast(replace(nullif(debt_eq        , '-'), ',', '') as decimal)   debt_eq            ,
    cast(replace(nullif(lt_debt_eq     , '-'), ',', '') as decimal)   lt_debt_eq         ,
    cast(replace(nullif(sma20_pct          , '-'), ',', '') as decimal)   sma20_pct              ,
    cast(replace(nullif(eps_ttm        , '-'), ',', '') as decimal)   eps_ttm            ,
    cast(replace(nullif(eps_next_y     , '-'), ',', '') as decimal)   eps_next_y         ,
    cast(replace(nullif(eps_next_q     , '-'), ',', '') as decimal)   eps_next_q         ,
    cast(replace(nullif(eps_this_y_pct     , '-'), ',', '') as decimal)   eps_this_y_pct         ,
    cast(replace(nullif(eps_next_y_pct , '-'), ',', '') as decimal)   eps_next_y_pct     ,
    cast(replace(nullif(eps_next_5y_pct    , '-'), ',', '') as decimal)   eps_next_5y_pct        ,
    cast(replace(nullif(eps_past_5y_pct    , '-'), ',', '') as decimal)   eps_past_5y_pct        ,
    cast(replace(nullif(sales_past_5y_pct  , '-'), ',', '') as decimal)   sales_past_5y_pct      ,
    cast(replace(nullif(sales_qq_pct       , '-'), ',', '') as decimal)   sales_qq_pct           ,
    cast(replace(nullif(eps_qq_pct         , '-'), ',', '') as decimal)   eps_qq_pct             ,
    nullif(earnings       , '-')                                          earnings           ,
    case when 
               abs(julianday(date('now')) -
                   julianday(date1)
                  )
             > abs(julianday(date('now')) -
                   julianday(date2) 
                  )
         then case when
                        abs(julianday(date('now')) -
                            julianday(date3)
                           )
                      > abs(julianday(date('now')) -
                            julianday(date2) 
                           )
                   then date2
                   else date3
              end
         else case when
                        abs(julianday(date('now')) -
                            julianday(date1)
                           )
                      > abs(julianday(date('now')) -
                            julianday(date3) 
                           )
                   then date3
                   else date1
              end              
    end                                                                as earnig_date            ,
    substr(earnings, 8, 3)                                             as report_type            ,
    cast(replace(nullif(sma50_pct          , '-'), ',', '') as decimal)   sma50_pct              ,
    cast(replace(nullif(insider_own_pct    , '-'), ',', '') as decimal)   insider_own_pct        ,
    cast(replace(nullif(insider_trans_pct  , '-'), ',', '') as decimal)   insider_trans_pct      ,
    cast(replace(nullif(inst_own_pct       , '-'), ',', '') as decimal)   inst_own_pct           ,
    cast(replace(nullif(inst_trans_pct     , '-'), ',', '') as decimal)   inst_trans_pct         ,
    cast(replace(nullif(roa_pct            , '-'), ',', '') as decimal)   roa_pct                ,
    cast(replace(nullif(roe_pct            , '-'), ',', '') as decimal)   roe_pct                ,
    cast(replace(nullif(roi_pct            , '-'), ',', '') as decimal)   roi_pct                ,
    cast(replace(nullif(gross_margin_pct   , '-'), ',', '') as decimal)   gross_margin_pct       ,
    cast(replace(nullif(oper_margin_pct    , '-'), ',', '') as decimal)   oper_margin_pct        ,
    cast(replace(nullif(profit_margin_pct  , '-'), ',', '') as decimal)   profit_margin_pct      ,
    cast(replace(nullif(payout_pct         , '-'), ',', '') as decimal)   payout_pct             ,
    cast(replace(nullif(sma200_pct         , '-'), ',', '') as decimal)   sma200_pct             ,
    case substr(shs_outstand_m, length(shs_outstand_m)) when '-' then null
                                                when 'T' then cast(substr(replace(shs_outstand_m, ',', ''), 1, length(replace(shs_outstand_m, ',', '')) - 1) as decimal)*1000000
                                                when 'B' then cast(substr(replace(shs_outstand_m, ',', ''), 1, length(replace(shs_outstand_m, ',', '')) - 1) as decimal)*1000
                                                when 'M' then cast(substr(replace(shs_outstand_m, ',', ''), 1, length(replace(shs_outstand_m, ',', '')) - 1) as decimal)
												when 'K' then round(cast(substr(replace(shs_outstand_m, ',', ''), 1, length(replace(shs_outstand_m, ',', '')) - 1) as decimal)/1000.0, 2)
												else round(cast(replace(shs_outstand_m, ',', '') as decimal)/1000000.0, 2)
    end as shs_outstand_m,
    case substr(shs_float_m, length(shs_float_m)) when '-' then null
                                                when 'T' then cast(substr(replace(shs_float_m, ',', ''), 1, length(replace(shs_float_m, ',', '')) - 1) as decimal)*1000000
                                                when 'B' then cast(substr(replace(shs_float_m, ',', ''), 1, length(replace(shs_float_m, ',', '')) - 1) as decimal)*1000
                                                when 'M' then cast(substr(replace(shs_float_m, ',', ''), 1, length(replace(shs_float_m, ',', '')) - 1) as decimal)
												when 'K' then round(cast(substr(replace(shs_float_m, ',', ''), 1, length(replace(shs_float_m, ',', '')) - 1) as decimal)/1000.0, 2)
												else round(cast(replace(shs_float_m, ',', '') as decimal)/1000000.0, 2)
    end as shs_float_m,
    cast(replace(nullif(short_float_pct    , '-'), ',', '') as decimal)   short_float_pct        ,
    round(case substr(shs_float_m, length(shs_float_m)) when '-' then null
                                                when 'T' then cast(substr(replace(shs_float_m, ',', ''), 1, length(replace(shs_float_m, ',', '')) - 1) as decimal)*1000000
                                                when 'B' then cast(substr(replace(shs_float_m, ',', ''), 1, length(replace(shs_float_m, ',', '')) - 1) as decimal)*1000
                                                when 'M' then cast(substr(replace(shs_float_m, ',', ''), 1, length(replace(shs_float_m, ',', '')) - 1) as decimal)
												when 'K' then round(cast(substr(replace(shs_float_m, ',', ''), 1, length(replace(shs_float_m, ',', '')) - 1) as decimal)/1000.0, 2)
												else round(cast(replace(shs_float_m, ',', '') as decimal)/1000000.0, 2)
    end * cast(replace(nullif(short_float_pct    , '-'), ',', '') as decimal) / 100.0 / 
    case substr(avg_volume_m, length(avg_volume_m)) when '-' then null
                                                when 'T' then cast(substr(replace(avg_volume_m, ',', ''), 1, length(replace(avg_volume_m, ',', '')) - 1) as decimal)*1000000
                                                when 'B' then cast(substr(replace(avg_volume_m, ',', ''), 1, length(replace(avg_volume_m, ',', '')) - 1) as decimal)*1000
                                                when 'M' then cast(substr(replace(avg_volume_m, ',', ''), 1, length(replace(avg_volume_m, ',', '')) - 1) as decimal)
												when 'K' then round(cast(substr(replace(avg_volume_m, ',', ''), 1, length(replace(avg_volume_m, ',', '')) - 1) as decimal)/1000.0, 2)
												else round(cast(replace(avg_volume_m, ',', '') as decimal)/1000000.0, 2)
    end, 2) as days_to_cover,    
    cast(replace(nullif(short_ratio    , '-'), ',', '') as decimal)   short_ratio        ,
    cast(replace(nullif(target_price   , '-'), ',', '') as decimal)   target_price       ,
    nullif(p52w_range     , '-')                                      p52w_range         ,
    cast(replace(nullif(p52w_high_pct      , '-'), ',', '') as decimal)   p52w_high_pct          ,
    cast(replace(nullif(p52w_low_pct       , '-'), ',', '') as decimal)   p52w_low_pct           ,
    cast(replace(nullif(rsi_14         , '-'), ',', '') as decimal)   rsi_14             ,
    cast(replace(nullif(rel_volume     , '-'), ',', '') as decimal)   rel_volume         ,
    case substr(avg_volume_m, length(avg_volume_m)) when '-' then null
                                                when 'T' then cast(substr(replace(avg_volume_m, ',', ''), 1, length(replace(avg_volume_m, ',', '')) - 1) as decimal)*1000000
                                                when 'B' then cast(substr(replace(avg_volume_m, ',', ''), 1, length(replace(avg_volume_m, ',', '')) - 1) as decimal)*1000
                                                when 'M' then cast(substr(replace(avg_volume_m, ',', ''), 1, length(replace(avg_volume_m, ',', '')) - 1) as decimal)
												when 'K' then round(cast(substr(replace(avg_volume_m, ',', ''), 1, length(replace(avg_volume_m, ',', '')) - 1) as decimal)/1000.0, 2)
												else round(cast(replace(avg_volume_m, ',', '') as decimal)/1000000.0, 2)
    end as avg_volume_m,
    case substr(volume_m, length(volume_m)) when '-' then null
                                                when 'T' then cast(substr(replace(volume_m, ',', ''), 1, length(replace(volume_m, ',', '')) - 1) as decimal)*1000000
                                                when 'B' then cast(substr(replace(volume_m, ',', ''), 1, length(replace(volume_m, ',', '')) - 1) as decimal)*1000
                                                when 'M' then cast(substr(replace(volume_m, ',', ''), 1, length(replace(volume_m, ',', '')) - 1) as decimal)
												when 'K' then round(cast(substr(replace(volume_m, ',', ''), 1, length(replace(volume_m, ',', '')) - 1) as decimal)/1000.0, 2)
												else round(cast(replace(volume_m, ',', '') as decimal)/1000000.0, 2)
    end as volume_m,
    cast(replace(nullif(perf_week_pct      , '-'), ',', '') as decimal)   perf_week_pct          ,
    cast(replace(nullif(perf_month_pct     , '-'), ',', '') as decimal)   perf_month_pct         ,
    cast(replace(nullif(perf_quarter_pct   , '-'), ',', '') as decimal)   perf_quarter_pct       ,
    cast(replace(nullif(perf_half_y_pct    , '-'), ',', '') as decimal)   perf_half_y_pct        ,
    cast(replace(nullif(perf_year_pct      , '-'), ',', '') as decimal)   perf_year_pct          ,
    cast(replace(nullif(perf_ytd_pct       , '-'), ',', '') as decimal)   perf_ytd_pct           ,
    cast(replace(nullif(beta           , '-'), ',', '') as decimal)   beta               ,
    cast(replace(nullif(atr            , '-'), ',', '') as decimal)   atr                ,
    nullif(volatility     , '-')                                      volatility         ,
    cast(replace(nullif(prev_close     , '-'), ',', '') as decimal)   prev_close         ,
    cast(replace(nullif(price          , '-'), ',', '') as decimal)   price              ,
    cast(replace(nullif(change_pct         , '-'), ',', '') as decimal)   change_pct     ,
    round(case substr(shs_outstand_m, length(shs_outstand_m)) when '-' then null
                                                when 'T' then cast(substr(replace(shs_outstand_m, ',', ''), 1, length(replace(shs_outstand_m, ',', '')) - 1) as decimal)*1000000
                                                when 'B' then cast(substr(replace(shs_outstand_m, ',', ''), 1, length(replace(shs_outstand_m, ',', '')) - 1) as decimal)*1000
                                                when 'M' then cast(substr(replace(shs_outstand_m, ',', ''), 1, length(replace(shs_outstand_m, ',', '')) - 1) as decimal)
												when 'K' then round(cast(substr(replace(shs_outstand_m, ',', ''), 1, length(replace(shs_outstand_m, ',', '')) - 1) as decimal)/1000.0, 2)
												else round(cast(replace(shs_outstand_m, ',', '') as decimal)/1000000.0, 2)
    end * cast(replace(nullif(price          , '-'), ',', '') as decimal), 2)  as market_cap_m2
 from (
    select *,
        (substr(date('now'), 1, 4) - 1) || '-' ||
                case substr(earnings, 1, 3) when 'Jan' Then '01'
                    when 'Feb' Then '02'
                    when 'Mar' Then '03'
                    when 'Apr' Then '04'
                    when 'May' Then '05'
                    when 'Jun' Then '06'
                    when 'Jul' Then '07'
                    when 'Aug' Then '08'
                    when 'Sep' Then '09'
                    when 'Oct' Then '10'
                    when 'Nov' Then '11'
                    when 'Dec' Then '12'
                end||'-'||
                substr(earnings, 5, 2) as date1,
        (substr(date('now'), 1, 4) - 0) || '-' ||
                case substr(earnings, 1, 3) when 'Jan' Then '01'
                    when 'Feb' Then '02'
                    when 'Mar' Then '03'
                    when 'Apr' Then '04'
                    when 'May' Then '05'
                    when 'Jun' Then '06'
                    when 'Jul' Then '07'
                    when 'Aug' Then '08'
                    when 'Sep' Then '09'
                    when 'Oct' Then '10'
                    when 'Nov' Then '11'
                    when 'Dec' Then '12'
                end||'-'||
                substr(earnings, 5, 2) as date2,
        (substr(date('now'), 1, 4) + 1) || '-' ||
                case substr(earnings, 1, 3) when 'Jan' Then '01'
                    when 'Feb' Then '02'
                    when 'Mar' Then '03'
                    when 'Apr' Then '04'
                    when 'May' Then '05'
                    when 'Jun' Then '06'
                    when 'Jul' Then '07'
                    when 'Aug' Then '08'
                    when 'Sep' Then '09'
                    when 'Oct' Then '10'
                    when 'Nov' Then '11'
                    when 'Dec' Then '12'
                end||'-'||
                substr(earnings, 5, 2) as date3
      from fundamentals);

