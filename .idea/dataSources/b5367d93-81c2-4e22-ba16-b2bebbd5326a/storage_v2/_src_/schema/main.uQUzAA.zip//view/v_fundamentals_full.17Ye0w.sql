CREATE VIEW v_fundamentals_full as
  select a.*, b.country, b.sector, b.industry
  from v_fundamentals a, v_companies b
  where a.data_date=b.data_date
        and a.ticker=b.ticker;

