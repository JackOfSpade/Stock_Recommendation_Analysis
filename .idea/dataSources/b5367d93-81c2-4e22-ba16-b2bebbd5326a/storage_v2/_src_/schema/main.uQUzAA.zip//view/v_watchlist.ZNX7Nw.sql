CREATE VIEW v_watchlist as
  select a.*, b.country, b.industry, b.sector
  from watchlist a, v_companies b
  where a.data_date = b.data_date
        and a.ticker = b.ticker;

