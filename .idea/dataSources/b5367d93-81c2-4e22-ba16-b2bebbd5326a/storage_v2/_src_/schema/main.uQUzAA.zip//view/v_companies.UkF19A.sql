CREATE VIEW v_companies as
  select
    data_date
    , ticker
    , company
    , sector
    , industry
    , country
    , case substr(market_cap, length(market_cap)) when '-' then null
      when 'T' then cast(substr(replace(market_cap, ',', ''), 1, length(replace(market_cap, ',', '')) - 1) as decimal)*1000000
      when 'B' then cast(substr(replace(market_cap, ',', ''), 1, length(replace(market_cap, ',', '')) - 1) as decimal)*1000
      when 'M' then cast(substr(replace(market_cap, ',', ''), 1, length(replace(market_cap, ',', '')) - 1) as decimal)
      when 'K' then round(cast(substr(replace(market_cap, ',', ''), 1, length(replace(market_cap, ',', '')) - 1) as decimal)/1000.0, 2)
      else round(cast(replace(market_cap, ',', '') as decimal)/1000000.0, 2)
      end as market_cap
    , cast(case when pe = '-' then null
           else pe
           end as decimal) as pe
    , cast(price as decimal) as price
    , cast(case substr(change, length(change)) when '-' then null
           when '%' then substr(change, 1, length(change) - 1)
           end as decimal) as change
    , cast(replace(volume, ',', '') as decimal) as volume
  from companies;

